ALTER TABLE `creature_template` DROP COLUMN `size`;
