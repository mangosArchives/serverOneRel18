DELETE FROM `spell_proc_event` WHERE `entry` IN (31801);
INSERT INTO `spell_proc_event` VALUES
(31801,0,0,0,0,0,1,20);
