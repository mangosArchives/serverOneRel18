DELETE FROM `spell_chain` WHERE `spell_id` IN (31895);

INSERT INTO `spell_chain` VALUES
(31895,20164,20164,2);
