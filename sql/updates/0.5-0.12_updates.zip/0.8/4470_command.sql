delete from command where name in('movegens');
INSERT INTO `command` VALUES
('movegens',3,'Syntax: .movegens\r\n  Show movement generators stack for selected creature or player.');

