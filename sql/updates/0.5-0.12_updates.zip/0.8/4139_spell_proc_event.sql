DELETE FROM `spell_proc_event` WHERE `entry` IN ( 11255, 12598 );
INSERT INTO `spell_proc_event` VALUES
(11255,32,0,0,3,0,16384,0),
(12598,32,0,0,3,0,16384,0);

