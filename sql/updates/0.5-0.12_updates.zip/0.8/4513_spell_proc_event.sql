DELETE FROM `spell_proc_event` WHERE `entry` IN (30482);
INSERT INTO `spell_proc_event` VALUES
(30482,0,0,0,0,0,2,0);
