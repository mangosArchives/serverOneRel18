ALTER TABLE `creature_template` ADD COLUMN dmgschool tinyint(1) not NULL default 0 after maxdmg;
