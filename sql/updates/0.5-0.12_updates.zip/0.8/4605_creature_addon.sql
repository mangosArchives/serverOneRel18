ALTER TABLE `creature_addon`
    DROP KEY `guid`,
    ADD PRIMARY KEY (`guid`);
