ALTER TABLE `creature_template_addon`
    DROP KEY `entry`,
    ADD PRIMARY KEY(`entry`);
