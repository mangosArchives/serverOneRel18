DELETE FROM `spell_chain` WHERE `spell_id` IN (27168);
INSERT INTO `spell_chain` VALUES
(27168,20914,20911,5);

DELETE FROM `spell_chain` WHERE `spell_id` IN (27169);
INSERT INTO `spell_chain` VALUES
(27169,25899,25899,2);
