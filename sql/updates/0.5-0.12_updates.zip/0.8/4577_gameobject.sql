ALTER TABLE `gameobject`
    CHANGE COLUMN `spawntimesecs` `spawntimesecs` int(11) NOT NULL default '0';
