INSERT INTO `command` ( `name` , `security` , `help` ) VALUES
('gogrid', '3', 'Syntax: .gogrid #gridX #gridY [#mapId]\n\nTeleport the gm to center of grid with provided indexes at map #mapId (or current map if it not provided).');

