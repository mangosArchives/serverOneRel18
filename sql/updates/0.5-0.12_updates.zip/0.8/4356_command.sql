DELETE FROM `command`  WHERE `name` = 'AddSpawn';
