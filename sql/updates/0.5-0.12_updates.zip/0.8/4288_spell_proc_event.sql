DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34320 );
INSERT INTO `spell_proc_event` VALUES
(34320,0,0,0,0,0,65536,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 38347 );
INSERT INTO `spell_proc_event` VALUES
(38347,0,0,0,0,0,65536,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 42083 );
INSERT INTO `spell_proc_event` VALUES
(42083,0,0,0,0,0,4198400,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 33012 );
INSERT INTO `spell_proc_event` VALUES
(33012,0,0,0,0,0,4,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 33014 );
INSERT INTO `spell_proc_event` VALUES
(33014,0,0,0,0,0,4,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 31794 );
INSERT INTO `spell_proc_event` VALUES
(31794,0,0,0,0,0,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 33089 );
INSERT INTO `spell_proc_event` VALUES
(33089,0,0,0,0,0,64,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 34586 );
INSERT INTO `spell_proc_event` VALUES
(34586,0,0,0,0,0,524289,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 38332 );
INSERT INTO `spell_proc_event` VALUES
(38332,0,0,0,0,0,134217728,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37657 );
INSERT INTO `spell_proc_event` VALUES
(37657,0,0,0,0,0,65536,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37195 );
INSERT INTO `spell_proc_event` VALUES
(37195,0,0,0,10,8388608,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37525 );
INSERT INTO `spell_proc_event` VALUES
(37525,0,0,0,0,0,1049602,0);
