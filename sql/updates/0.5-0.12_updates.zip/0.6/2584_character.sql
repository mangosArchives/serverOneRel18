ALTER TABLE `character`
  DROP `instanceid`;
