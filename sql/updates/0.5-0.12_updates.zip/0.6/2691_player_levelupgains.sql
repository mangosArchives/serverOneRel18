DROP TABLE IF EXISTS `player_levelupgains`;
