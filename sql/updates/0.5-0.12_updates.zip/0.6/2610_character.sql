UPDATE `character` SET `logout_time` = '0', `rest_bonus` = '0';
