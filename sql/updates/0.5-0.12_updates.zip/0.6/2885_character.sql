ALTER TABLE `character`
    DROP `realm`;
