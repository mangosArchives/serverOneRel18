ALTER TABLE `creature_loot_template`
  ADD `maxcount` int(11) unsigned NOT NULL default '1';

ALTER TABLE `fishing_loot_template`
  ADD `maxcount` int(11) unsigned NOT NULL default '1';

ALTER TABLE `gameobject_loot_template`
  ADD `maxcount` int(11) unsigned NOT NULL default '1';

ALTER TABLE `pickpocketing_loot_template`
  ADD `maxcount` int(11) unsigned NOT NULL default '1';

ALTER TABLE `skinning_loot_template`
  ADD `maxcount` int(11) unsigned NOT NULL default '1';

