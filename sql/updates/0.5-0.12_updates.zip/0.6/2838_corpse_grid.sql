ALTER TABLE `corpse_grid`     ENGINE = MEMORY;
