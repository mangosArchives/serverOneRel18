ALTER TABLE `npc_trainer`
  DROP `reqspell`;
