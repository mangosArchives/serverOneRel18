INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 47 , 20, '0', '1' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 47 , 20, '0', '2' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 54 , 18, '0', '1' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 54 , 18, '0', '2' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 68 , 17, '0', '2' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 68 , 17, '0', '1' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 69 , 21, '0', '1' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 69 , 21, '0', '2' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 72 , 19, '0', '1' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 72 , 19, '0', '2' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 76 , 14, '0', '2' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 76 , 14, '0', '1' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 81 , 16, '0', '2' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 81 , 16, '0', '1' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 530, 15, '0', '2' FROM `character` WHERE `race` = 1 OR `race` = 3 OR `race` = 4 OR `race` = 7;
INSERT IGNORE INTO `character_reputation` SELECT `character`.`guid`, 530, 15, '0', '1' FROM `character` WHERE `race` = 2 OR `race` = 5 OR `race` = 6 OR `race` = 8;

