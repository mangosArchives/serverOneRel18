DELETE FROM `spell_proc_event` WHERE `entry` IN ( 25252, 30339 );
INSERT INTO `spell_proc_event` VALUES
(25252,0,0,0,0,1,0),
(30339,0,0,0,0,1,0);
