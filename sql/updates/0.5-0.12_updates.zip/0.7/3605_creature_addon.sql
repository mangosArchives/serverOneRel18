ALTER TABLE `creature_addon`
  CHANGE COLUMN `entry` `guid` int(11) NOT NULL default '0';
