ALTER TABLE `mail`
  CHANGE COLUMN `itemPageId` `itemTextId` int(11) unsigned NOT NULL default '0';

