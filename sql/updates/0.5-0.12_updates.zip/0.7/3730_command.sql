INSERT INTO `command` VALUES('nametele',1,'Syntax: .nametele #playername #location\r\n\r\nTeleport a player to a given location.');
