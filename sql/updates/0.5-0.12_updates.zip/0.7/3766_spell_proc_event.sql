REPLACE INTO `spell_proc_event` VALUES (15286, 16, 0, 0, 0, 32768, 0);
REPLACE INTO `spell_proc_event` VALUES (34914, 16, 0, 0, 0, 32768, 0);
REPLACE INTO `spell_proc_event` VALUES (34916, 16, 0, 0, 0, 32768, 0);
REPLACE INTO `spell_proc_event` VALUES (34917, 16, 0, 0, 0, 32768, 0);