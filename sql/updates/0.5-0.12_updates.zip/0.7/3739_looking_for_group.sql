DROP TABLE IF EXISTS `looking_for_group`;
