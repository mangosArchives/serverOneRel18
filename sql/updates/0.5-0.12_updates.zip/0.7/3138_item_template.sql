ALTER TABLE `item_template`
  ADD `DisenchantID` int(11) unsigned NOT NULL default '0';
