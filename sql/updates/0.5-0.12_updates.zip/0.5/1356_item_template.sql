ALTER TABLE `item_template`
    CHANGE `dmg_min1` `dmg_min1` float NOT NULL default '0',
    CHANGE `dmg_max1` `dmg_max1` float NOT NULL default '0',
    CHANGE `dmg_min2` `dmg_min2` float NOT NULL default '0',
    CHANGE `dmg_max2` `dmg_max2` float NOT NULL default '0',
    CHANGE `dmg_min3` `dmg_min3` float NOT NULL default '0',
    CHANGE `dmg_max3` `dmg_max3` float NOT NULL default '0',
    CHANGE `dmg_min4` `dmg_min4` float NOT NULL default '0',
    CHANGE `dmg_max4` `dmg_max4` float NOT NULL default '0',
    CHANGE `dmg_min5` `dmg_min5` float NOT NULL default '0',
    CHANGE `dmg_max5` `dmg_max5` float NOT NULL default '0';
